dotcms-groupdocs-signature-source
=================================

DotCms Groupdocs Signature Source

```
${GroupDocsSignature.RenderIframe('your_signature_key', 'your_signature_form_guid', 800, 600)}
```

